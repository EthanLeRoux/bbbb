'use strict';

const fs = require('fs/promises');
const path = require('path');

// ─── Constants ────────────────────────────────────────────────────────────────

/** Folder that contains all domain subfolders inside the vault. */
const KNOWLEDGE_FOLDER = '01 Knowledge';

/** Regex for YAML front-matter block. */
const FRONTMATTER_RE = /^---\r?\n([\s\S]*?)\r?\n---/;

// ─── Helpers ──────────────────────────────────────────────────────────────────

/**
 * Parse YAML front-matter into a plain object.
 * Handles only simple `key: value` pairs (sufficient for this vault schema).
 *
 * @param {string} raw - Full file content.
 * @returns {Record<string, string>}
 */
function parseFrontmatter(raw) {
  const match = raw.match(FRONTMATTER_RE);
  if (!match) return {};

  return Object.fromEntries(
    match[1]
      .split(/\r?\n/)
      .map(line => {
        const colon = line.indexOf(':');
        if (colon === -1) return null;
        const key = line.slice(0, colon).trim();
        const value = line.slice(colon + 1).trim();
        return key ? [key, value] : null;
      })
      .filter(Boolean)
  );
}

/**
 * Derive a human-readable title from a note.
 * Priority: frontmatter `title:` → first `# Heading` → filename stem.
 *
 * @param {string} content
 * @param {string} fileName
 * @param {Record<string, string>} meta
 * @returns {string}
 */
function deriveTitle(content, fileName, meta) {
  if (meta.title) return meta.title;

  // First ATX heading that appears after the front-matter block
  const headingMatch = content.replace(FRONTMATTER_RE, '').match(/^#\s+(.+)$/m);
  if (headingMatch) return headingMatch[1].trim();

  return path.basename(fileName, '.md');
}

// ─── Types (JSDoc) ────────────────────────────────────────────────────────────

/**
 * Derive a stable slug ID from a string (lowercased, spaces→hyphens, non-alphanum stripped).
 * @param {string} str
 * @returns {string}
 */
function slugify(str) {
  return str
    .toLowerCase()
    .replace(/\s+/g, '-')
    .replace(/[^a-z0-9\-_]/g, '')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '');
}

/**
 * @typedef {Object} Note
 * @property {string} id        - Stable slug: "<domainSlug>/<sectionSlug>/<fileSlug>" (section omitted if root).
 * @property {string} domain
 * @property {string} section   - Empty string for root-level domain notes.
 * @property {string} title
 * @property {string} content
 * @property {string} filePath
 * @property {string} fileName
 * @property {Record<string, string>} meta  - Parsed front-matter fields.
 */

/**
 * @typedef {Object} SectionMap
 * @property {Note[]} notes
 */

/**
 * @typedef {Object} DomainMap
 * @property {Record<string, SectionMap>} sections
 * @property {number} noteCount
 */

/**
 * @typedef {Object} VaultStructure
 * @property {Record<string, DomainMap>} domains
 * @property {number} totalNotes
 */

// ─── Service ──────────────────────────────────────────────────────────────────

class VaultService {
  constructor() {
    const vaultPath = process.env.VAULT_PATH;
    if (!vaultPath) throw new Error('VAULT_PATH environment variable is required');

    /** @type {string} Absolute path to the Obsidian vault root. */
    this.vaultPath = vaultPath;

    /** @type {string} Absolute path to the `01 Knowledge` folder. */
    this.knowledgePath = path.join(vaultPath, KNOWLEDGE_FOLDER);

    /** @type {VaultStructure | null} In-process cache; cleared on demand. */
    this._cache = null;
  }

  // ── Cache management ────────────────────────────────────────────────────────

  /** Invalidate the in-memory scan cache (call after writing notes). */
  invalidateCache() {
    this._cache = null;
  }

  /**
   * Return a cached scan or run a fresh one.
   * @returns {Promise<VaultStructure>}
   */
  async _getStructure() {
    if (!this._cache) {
      this._cache = await this._scanKnowledge();
    }
    return this._cache;
  }

  // ── Scanning ────────────────────────────────────────────────────────────────

  /**
   * Scan `01 Knowledge/` and build the full vault structure.
   * Layout expected:
   *   01 Knowledge/<domain>/<section>/<note>.md
   *   01 Knowledge/<domain>/<note>.md          (section = '')
   *
   * @returns {Promise<VaultStructure>}
   */
  async _scanKnowledge() {
    /** @type {VaultStructure} */
    const structure = { domains: {}, totalNotes: 0 };

    let domainEntries;
    try {
      domainEntries = await fs.readdir(this.knowledgePath, { withFileTypes: true });
    } catch (err) {
      throw new Error(`Cannot read knowledge folder "${this.knowledgePath}": ${err.message}`);
    }

    for (const entry of domainEntries) {
      if (!entry.isDirectory()) continue;

      const domainName = entry.name;
      const domainPath = path.join(this.knowledgePath, domainName);
      const domain = await this._scanDomain(domainPath, domainName);

      structure.domains[domainName] = domain;
      structure.totalNotes += domain.noteCount;
    }

    return structure;
  }

  /**
   * Scan one domain directory.
   * @param {string} domainPath
   * @param {string} domainName
   * @returns {Promise<DomainMap>}
   */
  async _scanDomain(domainPath, domainName) {
    /** @type {DomainMap} */
    const domain = { sections: {}, noteCount: 0 };

    let entries;
    try {
      entries = await fs.readdir(domainPath, { withFileTypes: true });
    } catch (err) {
      throw new Error(`Failed to scan domain "${domainName}": ${err.message}`);
    }

    for (const entry of entries) {
      if (entry.isDirectory()) {
        const sectionName = entry.name;
        const sectionPath = path.join(domainPath, sectionName);
        domain.sections[sectionName] = await this._scanSection(sectionPath, domainName, sectionName);
      } else if (entry.isFile() && entry.name.endsWith('.md')) {
        // Root-level note (no subsection)
        const note = await this._readNote(domainPath, entry.name, domainName, '');
        if (note) {
          if (!domain.sections['_root']) domain.sections['_root'] = { notes: [] };
          domain.sections['_root'].notes.push(note);
        }
      }
    }

    // Single pass to tally all notes (avoids double-counting)
    for (const section of Object.values(domain.sections)) {
      domain.noteCount += section.notes.length;
    }

    return domain;
  }

  /**
   * Scan one section directory.
   * @param {string} sectionPath
   * @param {string} domainName
   * @param {string} sectionName
   * @returns {Promise<SectionMap>}
   */
  async _scanSection(sectionPath, domainName, sectionName) {
    /** @type {SectionMap} */
    const section = { notes: [] };

    let entries;
    try {
      entries = await fs.readdir(sectionPath, { withFileTypes: true });
    } catch (err) {
      throw new Error(`Failed to scan section "${sectionName}" in "${domainName}": ${err.message}`);
    }

    for (const entry of entries) {
      if (entry.isFile() && entry.name.endsWith('.md')) {
        const note = await this._readNote(sectionPath, entry.name, domainName, sectionName);
        if (note) section.notes.push(note);
      }
    }

    return section;
  }

  /**
   * Read and parse a single markdown note.
   * @param {string} dirPath
   * @param {string} fileName
   * @param {string} domainName
   * @param {string} sectionName
   * @returns {Promise<Note | null>}
   */
  async _readNote(dirPath, fileName, domainName, sectionName) {
    const filePath = path.join(dirPath, fileName);
    try {
      const content = await fs.readFile(filePath, 'utf8');
      const meta = parseFrontmatter(content);

      const domainSlug = slugify(domainName);
      const fileSlug = slugify(path.basename(fileName, '.md'));
      const id = sectionName
        ? `${domainSlug}/${slugify(sectionName)}/${fileSlug}`
        : `${domainSlug}/${fileSlug}`;

      return {
        id,
        domain: domainName,
        section: sectionName,
        title: deriveTitle(content, fileName, meta),
        content,
        filePath,
        fileName,
        meta,
      };
    } catch (err) {
      console.error(`[VaultService] Could not read "${filePath}": ${err.message}`);
      return null;
    }
  }

  // ── Public API ──────────────────────────────────────────────────────────────

  /**
   * Return a summary of every domain in the vault.
   * @returns {Promise<Array<{ name: string, noteCount: number, sections: string[] }>>}
   */
  async getAllDomains() {
    const { domains } = await this._getStructure();
    return Object.entries(domains).map(([name, domain]) => ({
      name,
      noteCount: domain.noteCount,
      sections: Object.keys(domain.sections),
    }));
  }

  /**
   * Return all sections (with their notes) within a domain.
   * @param {string} domainName
   * @returns {Promise<Array<{ name: string, noteCount: number, notes: Note[] }>>}
   */
  async getSectionsByDomain(domainName) {
    const { domains } = await this._getStructure();
    const domain = domains[domainName];
    if (!domain) throw new Error(`Domain "${domainName}" not found`);

    return Object.entries(domain.sections).map(([name, section]) => ({
      name,
      noteCount: section.notes.length,
      notes: section.notes,
    }));
  }

  /**
   * Return all notes in a specific section.
   * @param {string} domainName
   * @param {string} sectionName
   * @returns {Promise<Note[]>}
   */
  async getNotesBySection(domainName, sectionName) {
    const { domains } = await this._getStructure();
    const domain = domains[domainName];
    if (!domain) throw new Error(`Domain "${domainName}" not found`);

    const section = domain.sections[sectionName];
    if (!section) throw new Error(`Section "${sectionName}" not found in domain "${domainName}"`);

    return section.notes;
  }

  /**
   * Return all notes, optionally paginated.
   * @param {number | null} limit
   * @param {number} offset
   * @returns {Promise<Note[]>}
   */
  async getAllNotes(limit = null, offset = 0) {
    const { domains } = await this._getStructure();
    const all = [];

    for (const domain of Object.values(domains)) {
      for (const section of Object.values(domain.sections)) {
        all.push(...section.notes);
      }
    }

    return limit !== null ? all.slice(offset, offset + limit) : all;
  }

  /**
   * Full-text search across title and content.
   * Title matches rank above content matches.
   *
   * @param {string} keyword
   * @returns {Promise<Array<Note & { matchType: 'title' | 'content', relevance: number }>>}
   */
  async searchVault(keyword) {
    if (!keyword?.trim()) throw new Error('Search keyword is required');

    const term = keyword.toLowerCase().trim();
    const all = await this.getAllNotes();

    return all
      .reduce((acc, note) => {
        const inTitle = note.title.toLowerCase().includes(term);
        const inContent = note.content.toLowerCase().includes(term);
        if (inTitle || inContent) {
          acc.push({ ...note, matchType: inTitle ? 'title' : 'content', relevance: inTitle ? 2 : 1 });
        }
        return acc;
      }, [])
      .sort((a, b) => b.relevance - a.relevance);
  }

  /**
   * High-level stats about the vault.
   * @returns {Promise<{ totalDomains: number, totalNotes: number, domains: Array }>}
   */
  async getVaultStats() {
    const { domains, totalNotes } = await this._getStructure();
    return {
      totalDomains: Object.keys(domains).length,
      totalNotes,
      domains: Object.entries(domains).map(([name, domain]) => ({
        name,
        noteCount: domain.noteCount,
        sectionCount: Object.keys(domain.sections).length,
      })),
    };
  }
}

module.exports = VaultService;